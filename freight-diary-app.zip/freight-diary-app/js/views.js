export const msgHi = ()=>{
    return "Hi there!";
}