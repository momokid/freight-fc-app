<!-- Custom fonts for this template-->
<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

<!-- Custom styles for this template-->
<link href="css/sb-admin-2.css" rel="stylesheet">
<link href="css/jquery-ui.css" rel="stylesheet">
<link href="css/font-awesome-animation.min.css" rel="stylesheet">

<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon"/>
<link rel="icon" href="img/favicon.png">
<link rel="stylesheet" href="css/main.css?version=<?php echo rand() ?>" type="text/css" />
