<?php

//start the session
session_start();

//Database connection
include('cn/cn.php');
?>



<?php
$Uname = mysqli_real_escape_string($dbc, $_SESSION['Uname']);
$BranchID = mysqli_real_escape_string($dbc, $_SESSION['BranchID']);
$ActiveDate = mysqli_real_escape_string($dbc, $_SESSION['ActiveDay']);
//$e=  mysqli_real_escape_string($dbc,$_POST['e']);
//$TID=  mysqli_real_escape_string($dbc,$_POST['TID']);


if (!isset($_SESSION['Uname'])) {
    header('Location: login');
} else {

    $result = mysqli_query($dbc, "select * from inst_branch_view where BranchID='$BranchID'");
    $a =  mysqli_query($dbc, "SELECT * FROM rpt_multi_values where Username='$Uname'");

    if (mysqli_num_rows($result) == 0) {
        die('Company details not found');
    } elseif (mysqli_num_rows($result) == 1) {
        $r =  mysqli_fetch_assoc($result);

        if (mysqli_num_rows($a) == 0) {
            die('Invalid receipt no.');
        } elseif (mysqli_num_rows($a) > 0) {
            $an =  mysqli_fetch_assoc($a);
            $b = mysqli_query($dbc, "select * from hbl_invoice_view_0_1 where ReceiptNo='$an[SubjectID]'");

            if (mysqli_num_rows($b) == 0) {
                die("Transaction details not found");
            } else {
                $bn = mysqli_fetch_assoc($b);
?>
                <!DOCTYPE html>

                <html>

                <head>
                    <meta charset="utf-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <title>
                        <?php echo $bn['FullName'] . '  Invoice #' . $bn['ReceiptNo']; ?>
                    </title>

                    <?php include('script.php'); ?>

                </head>
                <body>
                <div class="no-print"><button id="btn-convert-val">Convert</button> <input type='number' id="convert-val" placeholder="Conversion Rate"> <input type='text' id="conversion-currency" placeholder="USD, EUR, CFA"></div>
                <div class='m-3 div-header-footer sr-only'><span class="top_first_header">BILL</span><span class="top_second_header bg-success">Custom Brokers & Freight Forwarding</span></div>
                <div style="height:1200px;" class="bg-original">
                    <table class='m-4 tbl-heading' style='width:980px;'>
                        <thead>
                            <tr>
                                <td>
                                    <div class='logo'></div>
                                </td>
                                <td colspan="2" style='font-size:34px;' class="sr-only">INVOICE <br><small>TIN: <b>C0015786307</b><small></td>
                                <td></td>
                            </tr>
                            <tr>
                            <td colspan="2">
                                    <div style='font-size: 25px;margin-top:0px;text-transform:uppercase;font-weight:bold;'>
                                        <span\> <?php echo $r['InstName']; ?> </span><br>
                                    </div>
                                </td>
                            </tr>
                            <tr style="border-top: 0px solid gray;border-bottom:1px solid gray;bottom:10px;">
                                <td colspan="4" style="padding-bottom:10px;">CUSTOM BROKERS, CONSOLIDATION, SEA & AIR FREIGHT, CLEARING & FORWADING, TRANSIT, HAULAGE, IMPORT & EXPORT</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td style="text-align: right;"><div style='text-align: right;margin-right:15px;' class="mt-4">Date:</div></td>
                                <td>
                                    <div style='text-align: center;border: 2px solid black;' class="mt-4"><?php echo strftime("%b %d,%Y", strtotime($bn['Date'])) ?></div>
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>
                                    <div class="sr-onlys" style='text-align: center;border-bottom: 1px solid gray;' class="mt-4"><?php echo $bn['HouseBL'] . ' - ' . $bn['ReceiptNo'] ?></div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div style='margin-left: 0;border-bottom: 1px solid gray;width:70%;'><b>BILL TO</b></div>

                                </td>
                                <td></td>
                                <td>
                                    <div style='border-bottom: 1px solid gray;width:70%;' class="sr-only"><b>TO:</b></div>

                                </td>

                                <td></td>
                            </tr>
                            <tr>
                            <?php
                                $c = mysqli_query($dbc, "select * from consignee_main where ConsigneeID='$bn[ConsigneeID]'");
                                if (mysqli_num_rows($c) <> 1) {
                                    die('System could not fetch consignee details');
                                } else {
                                    $cn = mysqli_fetch_assoc($c);
                                }
                                ?>
                                <td colspan="2">
                                    <div style='font-size: 18px;'>
                                        <span><b>Name: </b><?php echo $cn['FullName'] ?></span><br>
                                        <span><b>Address: </b><?php echo $cn['Address1'] ?></span><br>
                                        <span><?php echo $cn['Address2'] ?></span><br>
                                    </div>
                                </td>
                                <td colspan="2">
                                    <div style='font-size: 18px;margin-top:0px;' class="sr-only">
                                        <span> <?php echo $r['InstName']; ?> </span><br>
                                        <span><?php echo $r['Address']; ?></span><br>
                                        <span><?php echo $r['Location']; ?></span><br>
                                        <span><?php echo $r['TelNo']; ?></span><br>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div style="height:100px;"></div>
                                </td>
                            </tr>
                        </thead>
                    </table>
                    <div style="text-align: left;font-size:24px;font-weight:bold;display:inline-block;width:980px;">ITEM: <b><?php echo $bn['ItemDescription'] ?></b></div>
                    <table class="m-4" style='width:980px;font-size:20px'>
                        <thead>
                            <tr class="text-center font-weight-bold tbl-header" style="border:2px solid black;color:white;">
                                <td colspan="2"><div>DESCRIPTION</div></td>
                                <td class="text-center"><div>AMOUNT (GHC)</div></td>
                                <td class="text-center"><div>VAT(18.5%)</div></td>
                            </tr>
                            <thead>
                            <tbody class="content-tbl">
                                <?php
                                $b = mysqli_query($dbc, "select * from hbl_invoice_view_0_1 where ReceiptNo='$an[SubjectID]' order by Time asc");
                                while ($dn = mysqli_fetch_assoc($b)) {
                                ?>
                                    <tr class="td-sttmnt-details">
                                        <td colspan="2" class="text-center" style="text-transform: uppercase;"><?php echo $dn['AccountName']; ?></td>
                                        <td class="text-right"><?php echo number_format($dn['Fee'], 2, '.', ','); ?></td>
                                        <td class="text-right"><?php echo number_format($dn['GetVal']+$dn['VATVal'], 2, '.', ','); ?></td>
                                    </tr>
                                <?php } ?>

                                <?php
                              
                                $e = mysqli_query($dbc, "select sum(Fee) as TFee, sum(VATVal) as TVal, sum(GetVal) as TGetF from hbl_invoice_view_0_1 where ReceiptNo='$an[SubjectID]' and GetFundNHIL>0 and VAT>0");
                                $f = mysqli_query($dbc, "select sum(Fee) as TFee, sum(VATVal) as TVal, sum(GetVal) as TGetF from hbl_invoice_view_0_1 where ReceiptNo='$an[SubjectID]'");
                                
                                $en = mysqli_fetch_assoc($e);
                                $fn = mysqli_fetch_assoc($f);

                                $GetFund = round($en['TFee']*0.025,2);
                                $NHIL = round($en['TFee']*0.025,2);
                                $Covid = round($en['TFee']*0.01,2);
                                ?>
                                <tr>
                                    <td colspan="2" class="text-right">Sub Total</td>
                                    <td class="text-right" style="font-weight: bold;"><?php echo number_format($fn['TFee'], 2, '.', ','); ?></td>
                                    <td class="text-right"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="text-right">GetFUND (2.5%)</td>
                                    <td class="text-right"><?php echo number_format($GetFund, 2, '.', ','); ?></td>
                                    <td class="text-right"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="text-right">NHIL (2.5%)</td>
                                    <td class="text-right"><?php echo number_format($NHIL, 2, '.', ','); ?></td>
                                    <td class="text-right"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="text-right">Covid-19 LEVY (1%)</td>
                                    <td class="text-right"><?php echo number_format($Covid, 2, '.', ','); ?></td>
                                    <td class="text-right"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="text-right">VAT (12.5%)</td>
                                    <td class="text-right"><?php echo number_format($en['TVal'], 2, '.', ','); ?></td>
                                    <td class="text-right"></td>
                                </tr>
                                <tr style="font-size: 24px;">
                                    <td colspan="2" class="text-right"><b style="text-transform: uppercase;">Total Amount Payable</b></td>
                                    <td class="text-right"><b><?php echo number_format($fn['TFee'] + $en['TVal']+$en['TGetF'], 2, '.', ','); ?></b></td>
                                    <td class="text-right"></td>
                                </tr>
                            </tbody>
                    </table>
                    <div style="height:0px;"></div>
                    <table class="m-4 tbl-footer-sign" style='width:980px;font-size:16px'>
                        
                        <tr style="border-top: 3px solid gray;border-bottom:3px solid gray;">
                            <td colspan="4" style="padding-bottom:10px;"><b>Ghana Address:</b> <?php echo $r['Address']; ?></span>, <span><?php echo $r['Location']; ?></span> <br><b>Tel. No.:</b> <?php echo $r['TelNo']; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td colspan="2" class="text-center" style="padding-top:20px;"><b>ISSUED BY:</b></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td colspan="2" class="text-center" style="border-bottom:1px dotted black;padding-top: 15px;"><?php echo $_SESSION['FName']; ?></td>
                            <td></td>
                        </tr>
                        <tr style="border-top: 0px solid gray;border-bottom:0px solid gray;">
                            <td colspan="4" style="padding-bottom:0px;padding-top:40px;text-align:center;"><b>Thank you</b></td>
                        </tr>
                    </table>
                </div>
                <div class='bg-success m-3 div-header-footer'></div>
<?php  }
        }
    }
}
?>
                </body>
                </html>

                <style>
                    * {
                        font-family: Consolas, Tahoma, Arial;
                        color: black;
                    }

                    .tbl-heading td {
                        border: 0px solid black;
                        width: 25%;
                    }

                    .logo {
                        border: 0px solid gray;
                        background: url('<?php echo $loc; ?>/img/logo1<?php echo $logo_ext; ?>')no-repeat;
                        background-size: cover;
                    }

                    .div-header-footer {
                        width: 1000px;
                    }
                    .top_first_header{
                        width:200px;
                        background-color: black;
                        color: white;
                        line-height: 2.3rem;
                        font-size: 22px;
                        padding-left: 20px;
                        font-weight: bold;
                        display: inline-block;
                    }
                    .top_second_header{
                        width:800px;
                        background-color: #6c32ca;
                        color: black;
                        line-height: 2.3rem;
                        font-size: 22px;
                        text-align: center;
                        font-weight: bold;
                        display: inline-block;
                    }
                    .tbl-footer-sign td {
                        width: 25%;
                    }
                    .tbl-header td{
                        padding: 0px;
                    }

                    .tbl-header td div{
                        background-color: black;
                        color:white;
                        display: block;
                        padding: 0px;
                    }
                    .bg-original::before{
                        content: "ORIGINAL";
                        color: #d2cfcf;
                        font-size: 180px;
                        display: inline-block;
                        position: absolute;
                        top: 50%;
                        left: 5%;
                        -webkit-transform: rotate(40deg);
                        -moz-transform: rotate(40deg);
                        -o-transform: rotate(40deg);
                        transform: rotate(-50deg);
                        z-index: -1;
                        display: none;
                    }
                    .content-tbl td{
                        padding: 5px;
                        border: 1px solid gray;
                    }
                    @media print {
                        .no-print {
                            display: none;
                        }
                    }
                </style>
                <script src="vendor/jquery/jquery.min.js"></script>
                <script>
                    $('#btn-convert-val').click(function() {
                        let crt = $.trim($('#convert-val').val());
                        let crn = $.trim($('#conversion-currency').val());

                        if (crt == '') {
                            alert('Enter Conversion Rate');
                            return false;
                        } else if (crn == '') {
                            alert('Enter Conversion Currency');
                            return false;
                        } else {
                            $.post('add_temp_currency.php', {
                                crt: crt,
                                crn: crn
                            }, function(a) {
                                var win = window.open();
                                win.location = "invoice_other_services_currency_conversion.php", "_blank";
                                win.opener = null;
                                win.blur();
                                window.focus();
                            });
                        }
                    });
                </script>