<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.js?version=<?php echo rand() ?>"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js?version=<?php echo rand() ?>"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js?version=<?php echo rand() ?>"></script>
<script src="vendor/jquery/jquery-ui.js?version=<?php echo rand() ?>"></script>

<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js?version=<?php echo rand() ?>"></script>

<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js?version=<?php echo rand() ?>"></script>

<!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js?version=<?php echo rand() ?>"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js?version=<?php echo rand() ?>"></script>

<!-- Page level custom scripts -->
<script src="js/demo/datatables-demo.js?version=<?php echo rand() ?>"></script>

<!-- Page level custom scripts 
<script src="js/demo/chart-area-demo.js?version=<?php echo rand() ?>"></script>
-->
<script src="js/demo/chart-pie-demo.js?version=<?php echo rand() ?>"></script>


<script src="js/main.js?version=<?php echo rand(); ?>"></script>
<script src="js/graph.js?version=<?php echo rand(); ?>"></script>