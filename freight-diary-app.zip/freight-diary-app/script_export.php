<script src="js/export/es6-promise.auto.min.js"></script>
<script src="js/export/FileSaver.min.js"></script>
<script src="js/export/jspdf.min.js"></script>
<script src="js/export/jspdf.plugin.autotable.js"></script>
<script src="js/export/tableExport.min.js"></script>