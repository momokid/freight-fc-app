
function Spinner(){
  return `<div style="display:flex;align-items:center;justify-content:center;background-color:black;" class="spinner">
            <div style='font-size:30px;'>
              <i class='fa fa-spinner faa-spin animated fa-2x'></i>
            </div>
          </div>`;
  }
