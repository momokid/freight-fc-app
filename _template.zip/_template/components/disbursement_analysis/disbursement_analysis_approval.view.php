        <!-- Begin HBL Inovice Content -->
        <div class="container-fluid sub-basic-setup" id="disbursement-analysis-approval-panel">
          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">UNAUTHORISED DISBURSEMENT ANALYSIS</h1>
          </div>

          <!-- Content Row -->
          <div class="row" id="display_disbursement_analysis_panel">
            Loading disbursement for approval...
          </div>

        </div>
        <!-- /. End of HBL Invoice Content -->
