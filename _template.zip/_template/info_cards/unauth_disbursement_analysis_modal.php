<!-- Popup model for payment confirmation and delivery order request -->
<div class="modal fade" id="disbursementAnalysis" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-xl" role="document">
    <div class="modal-content" id="disbursementAnalysisModalContent">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title" id="exampleModalLabel">UNAUTHORISED DISBURSEMENT ANALYSIS</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">

        <div class="form-group row">
          <div class="col-lg-12 mb-4" id="display_disbursement_analysis">
          <i class="fa fa-spinner faa-spin animated fa-4x"></i>
          </div>
        </div>

      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>